var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'rooot',
  password : '',
  database : 'test_db'
});

connection.connect(function (error) {
    if (error) throw error;
    // console.log('Connected ');
  });
exports.con = connection;